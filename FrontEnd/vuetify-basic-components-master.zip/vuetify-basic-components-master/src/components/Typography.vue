<template>
  <div>
    <h3>Typography</h3>
    <v-card class="mt-5 mb-8">
      <v-card-text>
        <h1 class="display-4">Heading 1</h1>
        <h2 class="display-3">Heading 2</h2>
        <h3 class="display-2">Heading 3</h3>
        <h4 class="title">Title</h4>
        <h5 class="subtitle-1">Subtitle</h5>
        <p class="body-1">Body</p>
      </v-card-text>
    </v-card>
  </div>
</template>
